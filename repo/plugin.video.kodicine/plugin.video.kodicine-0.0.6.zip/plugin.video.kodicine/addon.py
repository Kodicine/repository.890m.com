import sys
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'movies')

url = 'https://r3---sn-p5qlsu7d.googlevideo.com/videoplayback?id=10fd04f446adea34&itag=37&source=picasa&requiressl=yes&pl=21&gir=yes&clen=2232700759&dur=6861&lmt=1433505693220528&mime=video/mp4&ip=177.16.159.208&ipbits=0&expire=1433716923&sparams=clen,dur,expire,gir,id,ip,ipbits,itag,lmt,mime,mm,mn,ms,mv,pl,requiressl,source&signature=07A588E99E50BD9E136A85317AE1EB61604DE694.2F640BB84360783424BB06D5F7A7FA751D347733&key=cms1&redirect_counter=1&req_id=3bd07d7078d9a3ee&cms_redirect=yes&mm=26&mn=sn-p5qlsu7d&ms=tsu&mt=1433688080&mv=m'
li = xbmcgui.ListItem('Noite Sem Fim 1080p', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/06/oRQgG6uK9W5aAdGO1dbGLcjSVRS.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=7eaa862c67c6a5ef&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434664787&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=3AD4EEFA4EA0793918F1E55B423B7FABBE57DCF9.32BC52226B85309C98E27496B35D9E800DF31426&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432072989&mv=m&pl=23'
li = xbmcgui.ListItem('Destino a Jumpiter', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/04/Capa3-200x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r3---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=8dcb286e4f77e915&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434665126&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=050CC0F5D8B50F42663B57EBCD0E6B3FE93EAB49.78E2A3928AF76CF3FDA8DA6132F48508035881AF&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432073229&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Mulher de preto 2', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/05/mF2u1E1ahv7NahNV9RODowYd8Qy.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=34eff38c65c9f6a9&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434665458&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=7A02A690745574C476229B876A889447AD6047CD.524B2C16B7A78B7D9EC271C621387ED02A3CAE26&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432073413&mv=m&pl=23'
li = xbmcgui.ListItem('Coracoes de Ferro (2014)', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/01/aeYCsbAlyc31CEguFcdhspysgdj.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r1---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=cdbba24de32f6204&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434665579&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=3DDEA7D9C59BDB16B81D8D1558B60B74EFB75B3E.29EBDF2DD442A73C93884FDA7E6F0300DFDDE034&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432073499&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Caminhos da Floresta', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/05/Capa-200x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=06a1aa4a8549fe00&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434665818&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=6356E64E0EF5F86C060DE214FA88C07FEBA17AAA.5842634CA8FE85001AFBFEFF6AB1EEDEFD589BCE&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432073756&mv=m&pl=23'
li = xbmcgui.ListItem('O Setimo Filho', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/04/Capa-200x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r1---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=075396df759f1530&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666109&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=81F75302E8334D0CDFC70905FFB2C8410201A261.651BC2B445B7C4C166B1D54099D98FACC2403A42&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432074016&mv=m&pl=23'
li = xbmcgui.ListItem('As Aventuras de Paddington', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/lKHjHibXZ9KFlGtqRXLOtH3tFIU.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r5---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=c39bbe77d5ccccbe&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666432&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=2D6A707AC0BFE24A2763F1ED709EBE6F9D4E890A.23E4F7CE38E21EAACC05AC013CD19B34F3E9A3E8&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432074351&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Premonicao 4', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/v04g1tE5wlsflwmhJTGH3YP2b4L.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r4---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=29f82ec23b94c910&itag=22&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666596&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=3990C6D0FABF7B894CCA573BBB70932AC4E10618.500FF4A973E6330F6DB44D428AEE3554088C504E&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432074514&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Loucas pra Casar', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/4lwuyg0btqYzS6LDhNZPLE40tca.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=9f3e7733013a7d74&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666767&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=4D618482CEEC13F681C36C860A71AD3ACB9D15F4.7194134E29C36537ADD7EA69392761DF392E2D81&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432074690&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Rampage 2', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/pSpChn2UgYNzRFA0eR3YyBuoOAo.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r3---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=1b6cf062a9157eac&itag=22&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666684&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=1E9375BCA067F5DFD4F0A1EF6583053253F145AD.71802D7D7B40A0819765DDF1BA70239A20AE2876&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432074855&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('A Casa dos Mortos', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/05/wY3pF51Td4eVorxL9qJc8wcDKDV.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=3e888fcd9dc64d03&itag=22&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666778&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=2A0ABDD41E86B03155BBE485A723F3E884E14E12.04B1FA92EE6304D8673581B93959B53F9197958C&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432074943&mv=m&pl=23'
li = xbmcgui.ListItem('Hacker', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/05/Capa1-200x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r1---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=f394b6a9596af8a6&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434666932&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=3C538053FB295EBE9E72F33F6D38771F5417D9D6.5CE391EE168A8A1DD955BF5BFF369408A0500ED6&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432075107&mv=m&pl=23'
li = xbmcgui.ListItem('Quero Matar Meu Chefe 2', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/02/u8Ci6XVA1DTvQ7AGXsiX3WNb2Wb.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r4---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=331569e99850e186&itag=22&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434667427&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=0EB64C4784559592CB8CDB1984FE74BEDD474457.1E3C0521F71D9B88F0666B200EA534A2C23A8105&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432075529&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('A Arte da Trapaca!', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/04/rykiTBwkMQmJTf9W5IhKYBf1oTq.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=4d841accbb8e83b9&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434667549&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=11CFCC85A6BA93E3CC612058A3332FFE819F2AA5.639A3FEAF8AEB1F6FF5E19DEDDB32139637779CE&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432075694&mv=m&pl=23'
li = xbmcgui.ListItem('Remanescentes', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/01/umsDLWVq27dROFHDLVK7y4WhLSz.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r1---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=81f2e2e5d7b86cd2&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434667730&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=516365A5F158221E699F382601729D28167BFC7A.58E2E3D1DFC85D1074A38EE5C36B39361B709E94&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432075858&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Operacao Big Hero', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/wjWhePIrOIdEXpDwnmSER3kLWdU.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r3---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=a74c696a91fe8282&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434668055&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=81453656048BEC920F96C6E0B88C639E1085879E.11961820560EEF51E16593A64806C956F963B9D4&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432076044&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Interestelar', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/h54I7hdRtB1a3370t0gd4nwPBGO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=1c77cab8618e660b&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434668234&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=20A37814532F0DD2973F109B1046F2972BEFCAA9.62FF732DDA1F46468AE40206BE7475154BABF918&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432076192&mv=m&pl=23'
li = xbmcgui.ListItem('Planeta dos Macacos O Confronto', iconImage='http://www.filmesonline2.com/wp-content/uploads/2014/08/Planeta-dos-Macacos-204x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=a8fe2ebf153fae73&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434668418&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=81ED3B08FBC7FF86EE264FA5323B6CE27C5EEF77.5927E17BB2F2F260B1279285156EA322129AE775&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432076517&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Jogos Vorazes A Espera', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/02/Face2-200x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=04a71d10ca59e497&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434668623&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=54F542E458281A1DB126713829445C99B1F4B556.3C2AF56D9110AD630445C2D8C26A89B6D2CCA787&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432076823&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Correr ou Morrer', iconImage='http://www.filmesonline2.com/wp-content/uploads/2014/12/MV5BMjUyNTA3MTAyM15BMl5BanBnXkFtZTgwOTEyMTkyMjE@._V1_SX214_AL_-202x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r1---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=433eab0ee88a8a9b&itag=37&source=webdrive&ip=200.146.45.83&ipbits=0&expire=1434669240&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=58271586C724B3D3A282C87F1D78403498FC1353.81FD572EAE53B5F774790293AA4089FC64896568&key=cms1&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432077187&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('As Tartarugas Ninja', iconImage='http://www.filmesonline2.com/wp-content/uploads/2014/11/MV5BNjUzODQ5MDY5NV5BMl5BanBnXkFtZTgwOTc1NzcyMjE@._V1_SX214_AL_-202x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=1fd94831b73baf98&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434669001&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=354E109A9BABAD9A29932420F391473200CA98CE.1FE32A06C9D336AC654E9D89C229BFDD66A9F159&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432076971&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('O Hobbit: A Batalha dos Cinco Exercitos FULLHD!!', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/03/sW7xjezL9Zm9jr4uujzlNuIZbKd.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=86fb6c03474a9de1&itag=37&source=picasa&ip=200.146.45.83&ipbits=0&expire=1434669412&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=26EAECE094181EA760B18C0803B0EAB69D437B6C.4BC50F15492B01D98C548333F996A9898145C7EE&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432077494&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Lucy', iconImage='http://www.filmesonline2.com/wp-content/uploads/2014/10/228587.jpg-r_640_600-b_1_D6D6D6-f_jpg-q_x-xxyxx-202x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r4---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=0ca16b334bdd764a&itag=37&source=webdrive&ip=200.146.45.83&ipbits=0&expire=1434669747&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=49768E689454FD55721B6F2BBC88C8D168EEC381.5E647F3A52856DB05ACCFFC7CE81FD5FB3624740&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432077655&mv=m&pcm2cms=yes&pl=23'
li = xbmcgui.ListItem('Capitao America 2 O Soldado Invernal ', iconImage='http://www.filmesonline2.com/wp-content/uploads/2014/08/14074268649736112103-213x300.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=b701ad77c14c9887&itag=37&source=picasa&ip=177.132.178.129&ipbits=0&expire=1434841297&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=74F0A2A6131CC5C451F27121FB8D49A394A099E4.1C35100437790E13EC28DD63F1E89011A2DA5D38&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432249209&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Projeto Almanaque', iconImage='http://3.bp.blogspot.com/-4rL-mGfasJA/VVaNUHF_5xI/AAAAAAAASjk/SQIDC6sj0eA/s320/ehtu6.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r5---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=15ba60e7943ddba5&itag=37&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434841672&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=73CFB96335C80828A73E925C7E4ED2887D6FD6B8.147FF5E60FEE193BBCDCFDFEDA39E939FF91C642&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432249573&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Eles Existem 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/assistir-online-eles-existem-hd-720p-dublado.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'http://upload.videoteca.biz/video/1432133761.mp4?Token=XDVsznscWftavaiCl&p=720p'
li = xbmcgui.ListItem('Relatos Selvagens 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/03/relatos-selvagens-poster-filmesonlinehd.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=4ba61d1b45d81d97&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434842123&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=36EA6B0B23581ED444B57400A22483CE88828588.610DB34578F199A13CFCAC74C15957F49A98CD64&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432250155&mv=m&pl=21'
li = xbmcgui.ListItem('Terra para Echo', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/assistir-online-terra-para-echo-hd-720p-dublado.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r5---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=0d2d34c6463befa7&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434842126&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=4B7AF073242ACE3832D0EC50530D711F0F8D989B.357671A183DF9A4EC16B5E860FFC19826F4B4749&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432250294&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Sobreviventes Backcountry 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/03/backcontry-dublado-hd-720p-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r5---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=95053cc3bd4f0ebc&itag=37&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434842497&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=6CAE54E09714B33422B2DE7296EDCE77A6E9196B.7E0AC2395D09D5C3CC6423C17C7E161F982BF669&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432250570&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Ex Machina Instinto Artificial 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/capa-filme-ex-machina-2015-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r3---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=f22d7cd42d2cc7f0&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434842787&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=4FE8FF92D2EFAD0E6FCB410E8BFE0C87C753F591.4BCEF6B141AC7E097B07348728E0C6026E32909D&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432250711&mv=m&pl=21'
li = xbmcgui.ListItem('Forca Maior 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/capa-filme-forca-maior-2015-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=ccc26107b30257b0&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434843404&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=816E8A4115D174F483D4F7BC5619FDFF62C2B2BB.4B93AF6B3A4D526809C3EE3F7F6D07047FE219CC&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432251361&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('A Familia Belier 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/assistir-online-a-familia-belier-hd-720p-dublado.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r4---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=1dc5273ed41e8273&itag=37&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434843524&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=4870A1BFEC78441193ACFCF7DEFB6D7037DF490A.4B5EFCEE7BFC1501A97556BFF6C551CA33B3728C&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432251565&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('O Homem com Punhos de Ferro 2 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/assistir-online-o-homem-dos-punhos-de-ferro-2-hd-720p-dublado.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=b8c2573d8a95cbc7&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434843627&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=3795E69E4582E6F0AB2DF5B946C0831E16638C6B.769A69FAEFEE0D721C98334967EF5CB1EFF8F63E&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432251785&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Bob Esponja Um Heroi Fora Da Agua 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/assistir-online-bob-esponja-um-heroi-fora-dagua-hd-720p-dublado.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=b801763e0af9e5b1&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434844237&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=17121ECD5DF49157FAA4DBA2BB15A38C89697115.6E2626C72A417D846F4CEBEF5E81C054315B9A28&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432252220&mv=m&pl=21'
li = xbmcgui.ListItem('Sniper Americano 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/01/sniper-americano-poster-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r5---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=1305c2d304bf0641&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434844435&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=2B3BA9E9D28BE2A046B38A4B88AD11EDF233465C.0B73ABCAF0AC10C14F1C6705C1A2E7D510F4E94A&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432252501&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('A Ressaca 2 Sem Sensura 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/04/assistir-a-ressaca-2-dublado-hd-720p-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'http://upload.videoteca.biz/video/1430837761.mp4?Token=blQnrcKJKLWKDNvUL&p=720p'
li = xbmcgui.ListItem('Bad Ass 3 Dois Duroes 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/assistir-online-bad-ass-3-hd-720p-dublado.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r4---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=364448e9c7f66b3b&itag=37&source=picasa&ip=177.132.178.129&ipbits=0&expire=1434845167&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=4DB8A21409D6C03B7C027582C79244AE522BD6B3.38B7B9A6D25FD332B041F332518AD8DACC08F081&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432253163&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Livre 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/04/assistir-livre-hd-1080p-dublado-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'http://s001.videopw.com/e/b53ce1fdb2fccec3a0898f3586ad5f9f.flv?st=7Euid5-AyT7umg0EAseYQg'
li = xbmcgui.ListItem('Kristy 720p', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/02/CO7bFrtiirBpXOamTfzvZQYtUV.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'http://upload.videoteca.biz/video/1432244884.mp4?Token=IuyFyGzlcDHuVplvy&p=720p'
li = xbmcgui.ListItem('Cinquenta Tons de Cinza 1080p', iconImage='http://www.sitedemulher.net/wp-content/uploads/2015/02/c2fe49e2capa_50tonsdecinza_filme.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=a449a2f49c3d035b&itag=37&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434846931&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=03DEB86E1BE081581E70A1D6B6BFB6785253D0CD.28D39FCEB996A3EA552604381E9DE91C10AF0653&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432254922&mv=m&pl=21'
li = xbmcgui.ListItem('Divida de Honra 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/05/capa-filme-divida-de-honra-2015-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r2---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=98e9a602ea5e92c1&itag=37&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434847084&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pl,requiressl,shardbypass,source&signature=4625B91B48BB9BEF25DAFD771204B3A0656D4169.2656559193E7B92F66EC28532273D785E7D633A1&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432255011&mv=m&pl=21'
li = xbmcgui.ListItem('O Jogo da Imitacao 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2015/01/o-jogo-da-intimida%C3%A7%C3%A3o-poster-filmesonlinehd1.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&id=81370a7591446e15&itag=37&source=picasa&ip=177.41.253.137&ipbits=0&expire=1435525589&sparams=expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,source&signature=6ED25D3547DDB7EE261795E6821272AF03EBC756.1A4F2C9CB9726D30A49EE42C0EA6E58083EA44DD&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432933546&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Dracula A Historia Nunca Contada 1080p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2014/11/dracula-a-historia-nunca-contada-filmesonlinehd1.fw_.fw_.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r6---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=340a88323952574f&itag=22&source=webdrive&ip=177.132.178.129&ipbits=0&expire=1434847499&sparams=cmbypass,expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,shardbypass,source&signature=0ED17BC13CF81C4425633A9ADF4E6A4B0C2EC0D3.47301D12FEAFB7FC61DCB361EE733E6BCE2F8987&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432255440&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('O Protetor 720p', iconImage='http://www.filmesonlinehd1.com/wp-content/uploads/2014/12/o-protetor-filmesonlinehd1.fw_.fw_1.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)



url = 'https://r3---sn-b8u-wvpe.googlevideo.com/videoplayback?requiressl=yes&id=10af25abcd70c2cd&itag=37&source=picasa&ip=177.41.253.137&ipbits=0&expire=1435525200&sparams=expire,id,ip,ipbits,itag,mm,mn,ms,mv,pcm2cms,pl,requiressl,source&signature=0CE6CE00B252DDD14E3610ED3D6B6F7502CC7B1D.3EC380B75FAC1A5FC8A4FA112329706DF604B29E&key=cms1&begin=0&cms_redirect=yes&mm=31&mn=sn-b8u-wvpe&ms=au&mt=1432933124&mv=m&pcm2cms=yes&pl=21'
li = xbmcgui.ListItem('Mapas Para as Estrelas 1080p', iconImage='http://www.filmesonline2.com/wp-content/uploads/2015/05/AvDuz23E36zy6IPVLNNpNrlWJsb.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)